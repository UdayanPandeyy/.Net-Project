﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.Models;
using WebApplication.New_project;

namespace WebApplication.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _db;

        public EmployeeController(ApplicationDbContext db)
        {
            _db = db; 
        }
        public IActionResult Index()
        {
            IEnumerable<Employee> objList = _db.employees;
            return View(objList);
        }

        // Get-Create
        public IActionResult Create()
        {
           //IEnumerable<Employee> objList = _db.employees;
            return View();
        }

        //POST-Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Employee obj)
        {
            _db.employees.Add(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }



        //POST-Update
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Update(Employee obj)
        {
            _db.employees.Update(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }



        //Get-Update
        public IActionResult Update(int? Phone)
        {

            //IEnumerable<Employee> objList = _db.employees;
            if (Phone == null || Phone == 0)
            {
                return NotFound();
            }
            var obj = _db.employees.Find(Phone);
            if (obj == null)
            {
                return NotFound();
            }
            return View(obj);
        }

        //Get-Delete
        public IActionResult Delete(int? Phone)
        {
            
            //IEnumerable<Employee> objList = _db.employees;
            if (Phone==null || Phone==0 )
            {
                return NotFound();
            }
            var obj = _db.employees.Find(Phone);
            if(obj==null)
            {
                return NotFound();
            }
            return View(obj);
        }

        //POST-Delete
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult PostDelete(int? Phone)
        {
            var obj = _db.employees.Find(Phone);
            if(obj==null)
            {
                return NotFound();
            }
            _db.employees.Remove(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}
